# Madkheda Lions Pro Live Scorer

## Controller
Open `index.html` normally.

## YouTube/PRISM/OBS Overlay
Use the same hosted `index.html` with:
`?mode=overlay&match=lions2026`

The controller and overlay use the same Firebase match ID (`lions2026`) and update live.
